import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class a_07_nov27c extends PApplet {

int rojo=PApplet.parseInt(random(255));
int verde=PApplet.parseInt(random(255));
int azul=PApplet.parseInt(random(255));
int cp=color(rojo, verde, azul);
PImage merca;

public void setup() {
  size(400, 400);
  merca=loadImage("leaves.jpg");
  noFill();
  strokeWeight(7);
  stroke(255);
}


public void draw() {
  cp=color(rojo, verde, azul);
  background(255);
  image(merca, 0, 0, 200, 400);
  PImage crop=get(mouseX, mouseY, 60, 80);
  image(crop, 200, 0, 200, 400);
  rect(mouseX, mouseY, 60, 80);
  if (mouseX<200 && mouseY<400) {
    for (int i=200; i<400; i++) {
      for (int j=0; j<400; j++) {
        set(i, j, get(i, j));
      }
    }
    for (int w=mouseX; w<mouseX+60; w++) {
      for (int h=mouseY; h<mouseY+80; h++) {
        set(w, h, get(w, h)+cp);
      }
    }
  }
}


public void mouseReleased() {
  rojo=PApplet.parseInt(random(255));
  verde=PApplet.parseInt(random(255));
  azul=PApplet.parseInt(random(255));
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "a_07_nov27c" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
